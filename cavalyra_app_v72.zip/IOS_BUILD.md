# Cavalyra – iOS Build Anleitung

Die App ist vollständig für iOS vorbereitet. Apple In-App Purchases werden später separat aktiviert (Stub liegt unter `public/billing/cavalyra-ios-billing.js`).

## Voraussetzungen (lokal, auf einem Mac)

- macOS mit aktuellem **Xcode** (≥ 15, getestet bis Xcode 16 / iOS 18 SDK, Apple Silicon kompatibel)
- **KEIN CocoaPods erforderlich** – dieses Projekt nutzt **Swift Package Manager (SPM)** über Capacitor 8. Alle Capacitor- und Cordova-Plugins werden automatisch via `ios/App/CapApp-SPM/Package.swift` eingebunden.
- Apple Developer Account (für Signing & App Store Connect)
- Node.js + npm

## Erstmaliger Setup

```bash
# Projekt aus dem Git ziehen / ZIP entpacken, dann auf dem Mac:
npm install
npm run build
npx cap sync ios
npx cap open ios     # öffnet Xcode

# Beim ersten Öffnen lädt Xcode automatisch alle Swift Packages
# (Capacitor + Plugins). Das kann 1–3 Minuten dauern – einfach warten.
```

> **Hinweis:** Es ist KEIN `pod install` nötig. Sollte Xcode dennoch eine
> Meldung zu Pods zeigen, einfach ignorieren – das Projekt verwendet
> ausschließlich Swift Package Manager.


## App in Xcode öffnen

```bash
npx cap open ios
```

Im Xcode-Projekt:

1. **Signing & Capabilities** → Team auswählen
2. **Bundle Identifier:** `de.cavalyra.app` (identisch zu Android)
3. **Display Name:** `Cavalyra`
4. **Deployment Target:** iOS 14.0+
5. **Capabilities aktivieren:** `Background Modes → Location updates` (für GPS-Ausritte) und später `In-App Purchase`.
6. Auf Gerät / Simulator starten (▶︎-Button).

## Wichtige Dateien

| Datei | Zweck |
|---|---|
| `capacitor.config.ts` | iOS-Block (`contentInset: 'always'`, Hintergrundfarbe, etc.) |
| `ios/App/App/Info.plist` | Alle Apple Privacy Usage Descriptions (Kamera, Fotos, Standort, Kalender, Tracking, FaceID) + `UIBackgroundModes = location` + `ITSAppUsesNonExemptEncryption = false` |
| `ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png` | App-Icon (1024×1024) |
| `public/billing/cavalyra-ios-billing.js` | Stub für spätere Apple In-App Purchases |

## Berechtigungs-Texte (bereits hinterlegt)

- **Kamera:** „Cavalyra benötigt Zugriff auf die Kamera, um Fotos deines Pferdes für den Body Scan aufzunehmen."
- **Fotos:** „Cavalyra benötigt Zugriff auf deine Fotos, um vorhandene Pferdebilder für den Body Scan auszuwählen."
- **Fotos sichern:** „Cavalyra speichert Body-Scan-Berichte und Pferdefotos in deiner Fotomediathek."
- **Standort:** „Cavalyra nutzt deinen Standort, um deine Ausritte per GPS aufzuzeichnen."
- **Standort (Hintergrund):** „Cavalyra nutzt deinen Standort, um Ausritte auch im Hintergrund weiter aufzuzeichnen."
- **Kalender:** „Cavalyra fügt Body-Scan-Termine und Ausritte zu deinem Kalender hinzu."

- **Face ID:** „Cavalyra kann Face ID zum schnellen und sicheren Entsperren deines Kontos verwenden."

## Funktionsabdeckung iOS

| Funktion | Plugin / Mechanik |
|---|---|
| Kamera & Fotogalerie | `@capacitor/camera` |
| Dateizugriff & PDF-Speicherung | `@capacitor/filesystem` (Directory.Documents → erscheint in der Dateien-App, da `UIFileSharingEnabled=true` und `LSSupportsOpeningDocumentsInPlace=true`) |
| PDF-Erstellung | `jsPDF` + `html2canvas` (clientseitig, identisch zu Android) |
| Teilen / Drucken / AirDrop / „In Dateien sichern" | `@capacitor/share` (öffnet das native iOS Share Sheet inkl. AirDrop, Drucken, Dateien) |
| Status Bar | `@capacitor/status-bar` (`style: DARK`, Hintergrund `#5c3540`) |
| Splashscreen | `@capacitor/splash-screen` (`launchShowDuration: 0` – kein zusätzlicher Splash, native LaunchScreen.storyboard) |
| GPS-Ausritt | `@capacitor/geolocation` + `UIBackgroundModes: location` |
| Deep Links / externe Links | Capacitor + `window.open(...)` (öffnet automatisch im Standard-Browser bzw. In-App-Webview je nach URL) |
| Sichere Speicherung | `@capacitor/preferences` (NSUserDefaults / Keychain) – bleibt bei App-Updates erhalten |
| Safe Area (Notch / Dynamic Island / iPad) | CSS `env(safe-area-inset-*)` im gesamten Layout |

## Apple In-App Purchases (StoreKit)

Voll aktiv via `cordova-plugin-purchase@13` (dasselbe Plugin wie Android, plattformbasiert umgeschaltet).

- **Produkt-ID (App Store Connect):** `de.cavalyra.app.pro.monthly`
- **Typ:** Auto-Renewable Subscription, 1 Monat, **6,99 €**, **3 Tage kostenlose Testphase**
- **Capability in Xcode aktivieren:** `Signing & Capabilities → + Capability → In-App Purchase`
- Die Kaufabwicklung läuft im Pro-Bereich der App – Buttons „3 Tage kostenlos testen" und „Käufe wiederherstellen" sind nativ via StoreKit angebunden (`public/billing/cavalyra-billing.js`).
- Beim App-Start werden vorhandene Abos automatisch via `restorePurchases()` erkannt und Pro freigeschaltet.
- Sandbox-Test: App-Store-Sandbox-Tester in Xcode/Settings → Developer hinterlegen, dann TestFlight-Build laden.

## App Store Veröffentlichung

1. In Xcode: **Product → Archive**
2. Im Organizer: **Distribute App → App Store Connect**
3. In App Store Connect: Datenschutz-Fragebogen ausfüllen
   - Erhobene Daten: Fotos (lokal verarbeitet), Standort (für Ausritte, optional), E-Mail (nur Login)
   - **App Tracking:** „Wir verfolgen Sie nicht."
4. Testflight → App Store Review einreichen.
